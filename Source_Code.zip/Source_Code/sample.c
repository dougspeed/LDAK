/*
Copyright 2024 Doug Speed.

    LDAK is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

    LDAK is distributed in the hope that they will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along with LDAK.  If not, see <http://www.gnu.org/licenses/>.

*/

///////////////////////////

//Sample individuals

///////////////////////////

//allocate variables

data_warn2(bitsize,num_samples_use+(1+num_subs)*num_inds);
data=malloc(sizeof(double)*num_samples_use*bitsize);
data2=malloc(sizeof(double)*num_inds*num_subs*bitsize);

parents=malloc(sizeof(int)*num_inds*num_subs);

//prepare for reading data
if(binary==0){open_datagz(&datainputgz, datafile, num_samples, genskip, genheaders, genprobs);}
current=0;

//allocate first parents at random
for(s=0;s<num_subs;s++)
{
for(i=0;i<num_inds;i++){parents[i+s*num_inds]=subindex[s][1+(int)(genrand_real1()*subindex[s][0])];}
}

//deal with progress file
sprintf(filename,"%s.progress",outfile);
if((output=fopen(filename,"w"))==NULL)
{printf("Error writing to %s; check you have permission to write and that there does not exist a folder with this name\n\n",filename);exit(1);}
fclose(output);

//open output
sprintf(filename2,"%s.bed", outfile);
if((output2=fopen(filename2,"wb"))==NULL)
{printf("Error writing to %s; check you have permission to write and that there does not exist a folder with this name\n\n",filename2);exit(1);}
onechar=108;fwrite(&onechar, sizeof(unsigned char), 1, output2);
onechar=27;fwrite(&onechar, sizeof(unsigned char), 1, output2);
onechar=1;fwrite(&onechar, sizeof(unsigned char), 1, output2);

//ready for bit loop
bittotal=(data_length-1)/bitsize+1;
for(bit=0;bit<bittotal;bit++)
{
bitstart=bit*bitsize;
bitend=(bit+1)*bitsize;
if(bitend>data_length){bitend=data_length;}
bitlength=bitend-bitstart;

printf("Generating data for Chunk %d of %d\n", bit+1, bittotal);
if((output=fopen(filename,"a"))==NULL)
{printf("Error re-opening %s\n\n",filename);exit(1);}
fprintf(output,"Generating data for Chunk %d of %d\n", bit+1, bittotal);
fclose(output);

current=read_data_fly(datafile, dtype, data, NULL, num_samples_use, keepsamps, bitstart, bitend, keeppreds_use, datainputgz, current, num_samples, num_preds, genskip, genheaders, genprobs, bgen_indexes, missingvalue, -9999, -9999, nonsnp, maxthreads);

for(j=0;j<bitlength;j++)
{
//see whether to update parents
for(s=0;s<num_subs;s++)
{
for(i=0;i<num_inds;i++)
{
if(genrand_real1()<0.01)	//update 
{parents[i+s*num_inds]=subindex[s][1+(int)(genrand_real1()*subindex[s][0])];}
}
}

//load up data
for(i=0;i<num_inds*num_subs;i++){data2[i+j*num_inds*num_subs]=data[parents[i]+j*num_samples_use];}
}

//save data
for(j=0;j<bitlength;j++)
{
for(i=0;i<num_inds*num_subs;i++)
{
value=data2[(size_t)j*num_inds*num_subs+i];

if(i%4==0){onechar=0;}
if(value==0){onechar+=(3<<(2*(i%4)));}
if(value==1){onechar+=(2<<(2*(i%4)));}
//if(value==2){onechar+=(0<<(2*(i%4)));}
if(value==missingvalue){onechar+=(1<<(2*(i%4)));}
if(i%4==3||i==num_inds*num_subs-1){fwrite(&onechar, sizeof(unsigned char), 1, output2);}
}
}
}	//end of bit loop

fclose(output2);

//write bim file
sprintf(filename3,"%s.bim", outfile);
if((output3=fopen(filename3,"w"))==NULL)
{printf("Error writing to %s; check you have permission to write and that there does not exist a folder with this name\n\n",filename3);exit(1);}
for(j=0;j<num_preds_use;j++)
{
fprintf(output3, "%d %s ", chr[j], preds[j]);
if(cm[j]==0){fprintf(output3, "0 ");}
else{fprintf(output3, "%.6f ", cm[j]);}
fprintf(output3, "%ld %s %s\n", (long int)bp[j], along1[j], along2[j]);
}
fclose(output3);

//write sample file
sprintf(filename4,"%s.fam", outfile);
if((output4=fopen(filename4,"w"))==NULL)
{printf("Error writing to %s; check you have permission to write and that there does not exist a folder with this name\n\n",filename4);exit(1);}
for(s=0;s<num_subs;s++)
{
for(i=0;i<num_inds;i++){fprintf(output4, "GROUP%d IND%d 0 0 0 NA\n", s+1, i+1);}
}
fclose(output4);

//free

free(data);free(data2);
free(parents);

///////////////////////////

