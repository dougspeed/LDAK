/*
Copyright 2024 Doug Speed.

    LDAK is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

    LDAK is distributed in the hope that they will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along with LDAK.  If not, see <http://www.gnu.org/licenses/>.

*/

///////////////////////////

//Convert summary statistics - mode 204

///////////////////////////

//want to set num_preds2, keeppreds_use2 and flippreds
keeppreds_use2=malloc(sizeof(int)*data_length);
flippreds=malloc(sizeof(int)*data_length);

//set filename, get num_preds2 and set keeppres_use2
sprintf(filename,"%s.cors.bim", borname);
num_preds2=countrows(filename);
printf("Re-reading details for %d predictors from %s\n", num_preds2, filename);

wantpreds=malloc(sizeof(char*)*num_preds2);
read_strings(filename, wantpreds, num_preds2, NULL, 2, 0);
count=find_strings(preds, data_length, wantpreds, num_preds2, NULL, keeppreds_use2, NULL, NULL, NULL, NULL, 3);
if(count<data_length){printf("Doug error 58BBE, only found %d of %d in %s\n\n",  count, data_length, filename);exit(1);}
for(j=0;j<num_preds2;j++){free(wantpreds[j]);}free(wantpreds);

//read and check alleles
cal1=malloc(sizeof(char*)*data_length);
cal2=malloc(sizeof(char*)*data_length);
read_strings(filename, cal1, data_length, keeppreds_use2, 5, 0);
read_strings(filename, cal2, data_length, keeppreds_use2, 6, 0);

for(j=0;j<data_length;j++)
{
readchar=cal1[j][0];
readchar2=cal2[j][0];
if((al1[j]!=readchar&&al1[j]!=readchar2)||(al2[j]!=readchar&&al2[j]!=readchar2))
{printf("Error, the alleles for Predictor %s in %s (%c and %c) are not consistent with those in %s (%c and %c)\n\n", preds[j], bimfile, al1[j], al2[j], filename, cal1[j][0], cal2[j][0]);exit(1);} 
flippreds[j]=(al1[j]!=cal1[j][0]);
}

count=0;for(j=0;j<data_length;j++){count+=flippreds[j];}
printf("will flip %d out of %d\n\n", count, data_length);

for(j=0;j<data_length;j++){free(cal1[j]);free(cal2[j]);}free(cal1);free(cal2);

//blank progress file
sprintf(filename,"%s.progress",outfile);
if((output=fopen(filename,"w"))==NULL)
{printf("Error writing to %s; check you have permission to write and that there does not exist a folder with this name\n\n",filename);exit(1);}
fclose(output);

////////

//first conversion 

//work out which predictors remain within each block
usedpreds=malloc(sizeof(int)*num_preds);
for(j=0;j<num_preds;j++){usedpreds[j]=0;}
for(j=0;j<data_length;j++){usedpreds[keeppreds_use[j]]=1;}

blockuse=malloc(sizeof(int *)*bittotal);
count=0;
for(bit=0;bit<bittotal;bit++)
{
blockuse[bit]=malloc(sizeof(int)*(2+blocklengths[bit]));
blockuse[bit][0]=count;
count2=0;
for(j=0;j<blocklengths[bit];j++)
{
if(usedpreds[blockstarts[bit]+j]==1){blockuse[bit][2+count2]=j;count2++;}
}
blockuse[bit][1]=count2;
count+=count2;
}

free(usedpreds);

//can exclude blocks that contain no predictors
count=0;
for(bit=0;bit<bittotal;bit++)
{
if(blockuse[bit][1]>0)
{
if(count!=bit)
{
blockstarts[count]=blockstarts[bit];
blockends[count]=blockends[bit];
blocklengths[count]=blocklengths[bit];
blockindexes[count]=blockindexes[bit];
free(blockuse[count]);
blockuse[count]=malloc(sizeof(int)*(2+blockuse[bit][1]));
memcpy(blockuse[count],blockuse[bit],sizeof(int)*(2+blockuse[bit][1]));
}
count++;
}
}

if(count<bittotal){printf("Warning, due to predictor filtering, the number of windows for first correlations has been reduced from %d to %d\n\n", bittotal, count);}
for(bit=count;bit<bittotal;bit++){free(blockuse[bit]);}
bittotal=count;

//get bitmax
bitmax=blockends[0]-blockstarts[0];
for(bit=1;bit<bittotal;bit++)
{
if(blockends[bit]-blockstarts[bit]>bitmax){bitmax=blockends[bit]-blockstarts[bit];}
}

//allocate variables used for first conversion

value=(double)bitmax/1024*bitmax/1024/1024*12;
if(value>1){printf("Warning, to store the first correlations requires %.1f Gb\n\n", value);}

cors_single=malloc(sizeof(float)*bitmax*bitmax);
cors=malloc(sizeof(double)*bitmax*bitmax);
cors2=malloc(sizeof(double)*bitmax);

blupmids=malloc(sizeof(double)*bitmax);

//open cors
sprintf(filename2,"%s.cors.bin", corname);
if((input2=fopen(filename2,"rb"))==NULL)
{printf("Error opening %s\n\n",filename2);exit(1);}

for(bit=0;bit<bittotal;bit++)
{
bitstart=blockuse[bit][0];
bitend=bitstart+blockuse[bit][1];
bitlength=blockuse[bit][1];
bitlength2=blockends[bit]-blockstarts[bit];

if(bit%50==0)
{
printf("Performing the first conversion for Window %d of %d\n", bit+1, bittotal);

sprintf(filename,"%s.progress",outfile);
if((output=fopen(filename,"a"))==NULL)
{printf("Error re-opening %s\n\n",filename);exit(1);}
fprintf(output,"Performing the first conversion for Window %d of %d\n", bit+1, bittotal);
fclose(output);
}

//read lower triangle correlations
fseeko(input2, (off_t)sizeof(double)*num_preds*4+sizeof(float)*blockindexes[bit], SEEK_SET);
for(k=0;k<bitlength2-1;k++)
{
count2=fread(cors_single+(size_t)k*bitlength2+k+1, sizeof(float), bitlength2-k-1, input2);
if(count2!=bitlength2-k-1)
{printf("Error reading correlations for Window %d from %s\n\n", bit+1, filename2);exit(1);}
}

//now extract correlations for predictors we are using
#pragma omp parallel for private(k,j) schedule(static)
for(k=0;k<bitlength;k++)
{
for(j=0;j<k;j++){cors[(size_t)k*bitlength+j]=cors_single[(size_t)blockuse[bit][2+j]*bitlength2+blockuse[bit][2+k]];}
cors[(size_t)k*bitlength+k]=1.0;
for(j=k+1;j<bitlength;j++){cors[(size_t)k*bitlength+j]=cors_single[(size_t)blockuse[bit][2+k]*bitlength2+blockuse[bit][2+j]];}
}

//get cholesky (saved in cors)
eigen_invert(cors, bitlength, cors2, 0, NULL, 1);

//pre-multiply effects by t(cors)
for(k=0;k<num_scores;k++)
{
for(j=0;j<bitlength;j++){blupmids[j]=blupfactors[k][bitstart+j];}

alpha=1.0;beta=0.0;
dgemv_("T", &bitlength, &bitlength, &alpha, cors, &bitlength, blupmids, &one, &beta, blupfactors[k]+bitstart, &one);
}
}	//end of bit loop
printf("\n");
fclose(input2);

//free
for(bit=0;bit<bittotal;bit++){free(blockuse[bit]);}free(blockuse);
free(cors_single);free(cors);free(cors2);
free(blupmids);

//any nas
count=0;
for(k=0;k<num_scores;k++)
{
for(j=0;j<data_length;j++)
{
if(blupfactors[k][j]!=blupfactors[k][j]||isinf(blupfactors[k][j]))
{
if(count<10){printf("Error score %d pred %d value %f\n\n", k+1, j+1, blupfactors[k][j]);}
count++;}
}
}
printf("one total errors %d\n", count);

////////

//second conversion

//flip effects if necessary
count=0;
for(k=0;k<num_scores;k++)
{
for(j=0;j<data_length;j++)
{
if(flippreds[j]==1){blupfactors[k][j]*=-1;count++;}
}
}
printf("count %d flipped\n", count);

//work out which predictors remain within each block
usedpreds=malloc(sizeof(int)*num_preds2);
for(j=0;j<num_preds2;j++){usedpreds[j]=0;}
for(j=0;j<data_length;j++){usedpreds[keeppreds_use2[j]]=1;}

blockuse2=malloc(sizeof(int *)*bittotal2);
count=0;
for(bit=0;bit<bittotal2;bit++)
{
blockuse2[bit]=malloc(sizeof(int)*(2+blocklengths2[bit]));
blockuse2[bit][0]=count;
count2=0;
for(j=0;j<blocklengths2[bit];j++)
{
if(usedpreds[blockstarts2[bit]+j]==1){blockuse2[bit][2+count2]=j;count2++;}
}
blockuse2[bit][1]=count2;
count+=count2;
}

free(usedpreds);

//can exclude blocks that contain no predictors
count=0;
for(bit=0;bit<bittotal2;bit++)
{
if(blockuse2[bit][1]>0)
{
if(count!=bit)
{
blockstarts2[count]=blockstarts2[bit];
blockends2[count]=blockends2[bit];
blocklengths2[count]=blocklengths2[bit];
blockindexes2[count]=blockindexes2[bit];
free(blockuse2[count]);
blockuse2[count]=malloc(sizeof(int)*(2+blockuse2[bit][1]));
memcpy(blockuse2[count],blockuse2[bit],sizeof(int)*(2+blockuse2[bit][1]));
}
count++;
}
}

if(count<bittotal2){printf("Warning, due to predictor filtering, the number of windows for second correlations has been reduced from %d to %d\n\n", bittotal2, count);}
for(bit=count;bit<bittotal2;bit++){free(blockuse2[bit]);}
bittotal2=count;

//get bitmax
bitmax2=blockends2[0]-blockstarts2[0];
for(bit=1;bit<bittotal2;bit++)
{
if(blockends2[bit]-blockstarts2[bit]>bitmax2){bitmax2=blockends2[bit]-blockstarts2[bit];}
}

//allocate variables used for second conversion

value=(double)bitmax2/1024*bitmax2/1024/1024*12;
if(value>1){printf("Warning, to store the second correlations requires %.1f Gb\n\n", value);}

cors_single=malloc(sizeof(float)*bitmax2*bitmax2);
cors=malloc(sizeof(double)*bitmax2*bitmax2);
cors2=malloc(sizeof(double)*bitmax2);

blupmids=malloc(sizeof(double)*bitmax2);

//open cors
sprintf(filename2,"%s.cors.bin", borname);
if((input2=fopen(filename2,"rb"))==NULL)
{printf("Error opening %s\n\n",filename2);exit(1);}

//read centres, allowing for filtering
fseeko(input2, 0, SEEK_SET);
current=0;
for(j=0;j<data_length;j++)
{
if(keeppreds_use[j]!=current)
{fseeko(input2, (off_t)sizeof(double)*keeppreds_use[j], SEEK_SET);}
if(fread(centres+j, sizeof(double), 1, input2)!=1)
{printf("Error reading mean for Predictor %d from %s\n\n", j+1, filename2);exit(1);}
current=keeppreds_use[j]+1;
}

for(bit=0;bit<bittotal2;bit++)
{
bitstart=blockuse2[bit][0];
bitend=bitstart+blockuse2[bit][1];
bitlength=blockuse2[bit][1];
bitlength2=blockends2[bit]-blockstarts2[bit];

if(bit%50==0)
{
printf("Performing the second conversion for Window %d of %d\n", bit+1, bittotal2);

sprintf(filename,"%s.progress",outfile);
if((output=fopen(filename,"a"))==NULL)
{printf("Error re-opening %s\n\n",filename);exit(1);}
fprintf(output,"Performing the second conversion for Window %d of %d\n", bit+1, bittotal2);
fclose(output);
}

//read lower triangle correlations
fseeko(input2, (off_t)sizeof(double)*num_preds2*4+sizeof(float)*blockindexes2[bit], SEEK_SET);
for(k=0;k<bitlength2-1;k++)
{
count2=fread(cors_single+(size_t)k*bitlength2+k+1, sizeof(float), bitlength2-k-1, input2);
if(count2!=bitlength2-k-1)
{printf("Error reading correlations for Window %d from %s\n\n", bit+1, filename2);exit(1);}
}

//now extract correlations for predictors we are using
#pragma omp parallel for private(k,j) schedule(static)
for(k=0;k<bitlength;k++)
{
for(j=0;j<k;j++){cors[(size_t)k*bitlength+j]=cors_single[(size_t)blockuse2[bit][2+j]*bitlength2+blockuse2[bit][2+k]];}
cors[(size_t)k*bitlength+k]=1.0;
for(j=k+1;j<bitlength;j++){cors[(size_t)k*bitlength+j]=cors_single[(size_t)blockuse2[bit][2+k]*bitlength2+blockuse2[bit][2+j]];}
}

//get inverse cholesky (saved in cors)
eigen_invert(cors, bitlength, cors2, -2, NULL, 1);

//pre-multiply effects by cors
for(k=0;k<num_scores;k++)
{
for(j=0;j<bitlength;j++){blupmids[j]=blupfactors[k][bitstart+j];}

alpha=1.0;beta=0.0;
dgemv_("N", &bitlength, &bitlength, &alpha, cors, &bitlength, blupmids, &one, &beta, blupfactors[k]+bitstart, &one);
}
}	//end of bit loop
printf("\n");
fclose(input2);

//any nas
count=0;
for(k=0;k<num_scores;k++)
{
for(j=0;j<data_length;j++)
{
if(blupfactors[k][j]!=blupfactors[k][j]||isinf(blupfactors[k][j]))
{
if(count<10){printf("Error score %d pred %d value %f\n\n", k+1, j+1, blupfactors[k][j]);}
count++;}
}
}
printf("two - total errors %d\n", count);

//flip back predictors if necessary
count=0;
for(k=0;k<num_scores;k++)
{
for(j=0;j<data_length;j++)
{
if(flippreds[j]==1){blupfactors[k][j]*=-1;count++;}
}
}
printf("count %d flipped\n", count);

//free
for(bit=0;bit<bittotal2;bit++){free(blockuse2[bit]);}free(blockuse2);
free(cors_single);free(cors);free(cors2);
free(blupmids);

////////

//save results

sprintf(filename2,"%s.converted.effects", outfile);
if((output2=fopen(filename2,"w"))==NULL)
{printf("Error re-opening %s\n\n",filename2);exit(1);}
fprintf(output2,"Predictor A1 A2 Centre");
for(k=0;k<num_scores;k++){fprintf(output2," Effect%d", k+1);}
fprintf(output2,"\n");

for(j=0;j<data_length;j++)
{
fprintf(output2, "%s %c %c ", preds[j], al1[j], al2[j]);
if(blupcentres[0][j]!=-9999){fprintf(output2, "%.6f", blupcentres[0][j]);}
else{fprintf(output2, "NA");}
for(k=0;k<num_scores;k++){fprintf(output2, " %.4e", blupfactors[k][j]);}
fprintf(output2,"\n");
}
fclose(output2);

printf("Converted summary statistics saved in %s\n\n", filename2);

//free allocations from setdl.c
for(k=0;k<num_scores;k++){free(blupcentres[k]);free(blupfactors[k]);}free(blupcentres);free(blupfactors);

//frees from above
free(keeppreds_use2);
free(flippreds);

///////////////////////////

